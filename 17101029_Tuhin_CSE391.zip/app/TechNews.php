<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TechNews extends Model
{
    //
}
