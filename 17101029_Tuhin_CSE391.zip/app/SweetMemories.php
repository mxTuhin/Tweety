<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SweetMemories extends Model
{
    //
    protected $fillable = [
        'user_id', 'img'
    ];
}
