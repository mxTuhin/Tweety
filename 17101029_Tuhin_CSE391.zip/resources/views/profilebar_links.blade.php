<li  class="@yield('show_prof_link')"><a href="{{route('profile', $user)}}">timeline</a></li>
<li  class="@yield('about_prof_link')"><a href="{{route('about', $user)}}">about</a></li>
<li  class="@yield('photos_prof_link')"><a href="{{route('photos', $user)}}">photos</a></li>
<li  class="@yield('friends_prof_link')"><a href="{{route('friends', $user)}}">friends</a></li>
