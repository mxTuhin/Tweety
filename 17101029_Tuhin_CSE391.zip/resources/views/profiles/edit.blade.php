@extends('layouts.app')

@section('content')
    Edit the profile for {{$user->name}}
    @endsection
