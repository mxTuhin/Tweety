

    <li class="unorder-list">
        <!-- profile picture end -->
        <div class="profile-thumb">
            <a href="<?php echo e(route('profile',$users)); ?>">
                <figure class="profile-thumb-small">
                    <img src="<?php echo e(asset("user/images/profile")); ?>/<?php echo e($users->profile_img); ?>" alt="profile picture">
                </figure>
            </a>
        </div>
        <!-- profile picture end -->

        <div class="unorder-list-info">
            <h3 class="list-title"><a href="<?php echo e(route('profile',$users)); ?>"><?php echo e($users->name); ?></a></h3>
            <p class="list-subtitle"><?php echo e($users->bio); ?></p>
        </div>
        <button onclick="send_anger('<?php echo e($users->id); ?>', '<?php echo e($users->name); ?>')" id="send_love<?php echo e($users->id); ?>" class="send_love_button" style="margin-left: 20px; " class="btn btn-sm" data-toggle="tooltip" data-placement="right" title="Send Anger xD">
            <i style="font-size: 20px" class="far fa-angry"></i>
        </button>
    </li>

<?php /**PATH E:\XaMpP\htdocs\tweety\resources\views/_friends-list.blade.php ENDPATH**/ ?>