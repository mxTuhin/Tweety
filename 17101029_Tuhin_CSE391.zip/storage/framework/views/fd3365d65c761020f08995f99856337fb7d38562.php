<?php $__env->startSection('title', 'Profile'); ?>
<?php $__env->startSection('show_prof_link', 'active'); ?>

<?php $__env->startSection('profile_content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-3 order-2 order-lg-1">
                <aside class="widget-area profile-sidebar">
                    <!-- widget single item start -->
                    <div class="card widget-item">
                        <h4 class="widget-title"><?php echo e($user->name); ?></h4>
                        <div class="widget-body">
                            <div class="about-author">
                                <p><?php echo e($user->bio); ?></p>
                                <ul class="author-into-list">
                                    <li><i class="fas fa-briefcase"></i> <?php echo e($user->workplace); ?></li>
                                    <li><i class="fas fa-home"></i> <?php echo e($user->home); ?></li>
                                    <li><i class="fa fa-university"></i> <?php echo e($user->institution); ?></li>

                                    <li><i class="fas fa-heartbeat"></i> <?php echo e($user->hobby); ?></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <!-- widget single item end -->

                    <!-- widget single item start -->
                    <div class="card widget-item">
                        <h4 class="widget-title">Sweets Memories</h4>
                        <div class="widget-body">
                            <div class="sweet-galley img-gallery">
                                <div class="row row-5">
                                    <?php $__currentLoopData = $user->sweet_memories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mems): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-4">
                                            <div class="gallery-tem">
                                                <figure class="post-thumb">
                                                    <a class="gallery-selector" href="<?php echo e(asset('user/images/uploads')); ?>/<?php echo e($mems->img); ?>">
                                                        <img style="height: 80px" src="<?php echo e(asset('user/images/uploads')); ?>/<?php echo e($mems->img); ?>" alt="Sweet Memories">
                                                    </a>
                                                </figure>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <div class="col-4">
                                        <div style="margin-top: 20px" >
                                            <figure class="post-thumb">
                                                <button data-toggle="modal" data-target="#sweetMemoriesModal" >
                                                    <i style="font-size: 40px; color: #5ec9d1" class="fas fa-plus"></i>
                                                </button>
                                            </figure>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- widget single item end -->

                    <!-- widget single item start -->
                    <div class="card widget-item">
                        <h4 class="widget-title">People You may Know</h4>
                        <div class="widget-body">
                            <ul class="like-page-list-wrapper">
                                <?php if($user_list->count() >=1): ?>
                                    <?php $__currentLoopData = $user_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo $__env->make('_mayKnowFriends', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                    <!-- widget single item end -->
                </aside>
            </div>

            <div class="col-lg-6 order-1 order-lg-2">
                <?php if(current_user()->is($user)): ?>
                    <?php echo $__env->make('_publish-tweet-panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>

                <?php $__currentLoopData = $user->tweets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tweet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('_angry-tweets', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="col-lg-3 order-3">
                <aside class="widget-area">
                    <?php if(current_user()->is($user)): ?>
                    <!-- widget single item start -->
                    <div class="card widget-item">
                        <h4 class="widget-title">To Do List</h4>
                        <div class="widget-body">
                            <ul class="like-page-list-wrapper">
                                <?php $__currentLoopData = auth()->user()->to_do_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo $__env->make('to_do_list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>
                        </div>
                        <hr>
                        <div class="widget-item">
                            <form action="<?php echo e(route('store_todo_list')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input id="todo_list_input" class="form-control" name="todo_list" placeholder="Type ToDo Work and Press Enter">
                            </form>
                        </div>

                    </div>
                    <!-- widget single item end -->
                    <?php endif; ?>

                    <!-- widget single item start -->
                    <div class="card widget-item">
                        <h4 class="widget-title">Advertisement</h4>
                        <?php $__currentLoopData = $advertises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="widget-body">
                                <div class="add-thumb">
                                    <a href="<?php echo e($advert->link); ?>">
                                        <img src="<?php echo e($advert->image); ?>" alt="advertisement">
                                    </a>
                                </div>
                            </div>
                            <h4 class="widget-title"></h4>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <!-- widget single item end -->

                    <!-- widget single item start -->
                    <div class="card widget-item">
                        <h4 class="widget-title">Users Friend List</h4>
                        <div class="widget-body">

                            <ul class="like-page-list-wrapper">
                                <?php $__currentLoopData = $user->follows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo $__env->make('_friends-list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>
                        </div>
                    </div>
                    <!-- widget single item end -->
                </aside>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="sweetMemoriesModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">Select From Images</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                    <?php $__currentLoopData = $user->gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $images): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-4 col-sm-4">
                            <a href="<?php echo e(route('add_sweet_memory', $images->img)); ?>">
                                <img style="height: 200px" src="<?php echo e(asset("user/images/uploads")); ?>/<?php echo e($images->img); ?>">
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboardJS'); ?>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('profiles.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\XaMpP\htdocs\tweety\resources\views/profiles/show.blade.php ENDPATH**/ ?>