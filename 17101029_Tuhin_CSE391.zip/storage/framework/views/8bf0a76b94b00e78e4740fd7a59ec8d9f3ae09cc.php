<li  class="<?php echo $__env->yieldContent('show_prof_link'); ?>"><a href="<?php echo e(route('profile', $user)); ?>">timeline</a></li>
<li  class="<?php echo $__env->yieldContent('about_prof_link'); ?>"><a href="<?php echo e(route('about', $user)); ?>">about</a></li>
<li  class="<?php echo $__env->yieldContent('photos_prof_link'); ?>"><a href="<?php echo e(route('photos', $user)); ?>">photos</a></li>
<li  class="<?php echo $__env->yieldContent('friends_prof_link'); ?>"><a href="<?php echo e(route('friends', $user)); ?>">friends</a></li>
<?php /**PATH E:\XaMpP\htdocs\tweety\resources\views/profilebar_links.blade.php ENDPATH**/ ?>