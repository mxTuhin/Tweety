<?php $__env->startSection('title', "Timeline"); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-wrapper pt-80">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 order-2 order-lg-1">
                    <aside class="widget-area">
                        <!-- widget single item start -->
                        <div class="card card-profile widget-item p-0">
                            <div class="profile-banner">
                                <figure class="profile-banner-small">
                                    <a href="<?php echo e(route('profile', auth()->user())); ?>">
                                        <img src="user/images/banner/banner-small.jpg" alt="">
                                    </a>
                                    <a href="<?php echo e(route('profile', auth()->user())); ?>" class="profile-thumb-2">
                                        <img src="<?php echo e(asset("user/images/profile")); ?>/<?php echo e(auth()->user()->profile_img); ?>" alt="">
                                    </a>
                                </figure>
                                <div class="profile-desc text-center">
                                    <h6 class="author"><a href="<?php echo e(route('profile', auth()->user())); ?>"><?php echo e(auth()->user()->name); ?></a></h6>
                                    <p><?php echo e(auth()->user()->bio); ?></p>
                                </div>
                            </div>
                        </div>
                        <!-- widget single item start -->

                        <!-- widget single item start -->
                        <div class="card widget-item">
                            <h4 class="widget-title">People You May Know</h4>
                            <div class="widget-body">
                                <ul class="like-page-list-wrapper">
                                    <?php if($user_list->count() >=1): ?>
                                        <?php $__currentLoopData = $user_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo $__env->make('_mayKnowFriends', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                        <!-- widget single item end -->

                        <!-- widget single item start -->
                        <div class="card widget-item">
                            <h4 class="widget-title">latest Tech News</h4>
                            <div class="widget-body">
                                <ul class="like-page-list-wrapper">
                                    <?php $__currentLoopData = $tech_news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="unorder-list">
                                            <!-- profile picture end -->
                                            <div class="profile-thumb">
                                                <a href="#">
                                                    <figure class="profile-thumb-small">
                                                        <img src="<?php echo e($news->image); ?>" alt="profile picture">
                                                    </figure>
                                                </a>
                                            </div>
                                            <!-- profile picture end -->

                                            <div class="unorder-list-info">
                                                <h3 class="list-title"><a href="<?php echo e($news->link); ?>" target="_blank"><?php echo e($news->title); ?></a></h3>
                                                <p class="list-subtitle"><?php echo e(date('h:i:s a m/d/Y', strtotime($news->created_at))); ?></p>
                                            </div>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                        <!-- widget single item end -->
                    </aside>
                </div>

                <div class="col-lg-6 order-1 order-lg-2">
                    <!-- share box start -->
                    <?php echo $__env->make('_publish-tweet-panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <?php $__currentLoopData = auth()->user()->tweets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tweet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($tweet->status=="show"): ?>
                                <?php echo $__env->make('_angry-tweets', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

                <div class="col-lg-3 order-3">
                    <aside class="widget-area">
                        <div class="card widget-item">
                            <h4 class="widget-title">To Do List</h4>
                            <div class="widget-body">
                                <ul class="like-page-list-wrapper">
                                    <?php $__currentLoopData = auth()->user()->to_do_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo $__env->make('to_do_list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </ul>
                            </div>
                            <hr>
                            <div class="widget-item">
                                <form action="<?php echo e(route('store_todo_list')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input id="todo_list_input" class="form-control" name="todo_list" placeholder="Type ToDo Work and Press Enter">
                                </form>
                            </div>

                        </div>

                        <!-- widget single item end -->

                        <!-- widget single item start -->
                        <div class="card widget-item">
                            <h4 class="widget-title">Advertisement</h4>
                            <?php $__currentLoopData = $advertises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="widget-body">
                                    <div class="add-thumb">
                                        <a href="<?php echo e($advert->link); ?>">
                                            <img src="<?php echo e($advert->image); ?>" alt="advertisement">
                                        </a>
                                    </div>
                                </div>
                                <h4 class="widget-title"></h4>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <!-- widget single item end -->

                        <!-- widget single item start -->
                        <div class="card widget-item">
                            <h4 class="widget-title">Friend List</h4>
                            <div class="widget-body">
                                <ul class="like-page-list-wrapper">
                                    <ul class="bg-blue-100 rounded-lg p-4">
                                    <?php $__currentLoopData = auth()->user()->follows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo $__env->make('_friends-list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>


                                </ul>
                            </div>
                        </div>
                        <!-- widget single item end -->
                    </aside>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboardJS'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\XaMpP\htdocs\tweety\resources\views/_timeline.blade.php ENDPATH**/ ?>