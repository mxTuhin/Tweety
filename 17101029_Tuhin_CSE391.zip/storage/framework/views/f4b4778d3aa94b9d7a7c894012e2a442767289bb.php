<li class="unorder-list">
    <!-- profile picture end -->
    <div class="profile-thumb">
        <a href="<?php echo e(route('profile',$users)); ?>">
            <figure class="profile-thumb-small">
                <img src="<?php echo e(asset("user/images/profile")); ?>/<?php echo e($users->profile_img); ?>" alt="profile picture">
            </figure>
        </a>
    </div>
    <!-- profile picture end -->

    <div class="unorder-list-info">
        <h3 class="list-title"><a href="<?php echo e(route('profile',$users)); ?>"><?php echo e($users->name); ?></a></h3>
        <p class="list-subtitle"><a href="<?php echo e(route('profile',$users)); ?>"><?php echo e($users->bio); ?></a></p>
    </div>
    <button onclick="follow_user('<?php echo e($users->id); ?>')" style="margin-left:30px" class=" btn-sm">
        <i id="follow_user_icon_<?php echo e($users->id); ?>" class="fas fa-user-plus"></i>
    </button>
</li>
<?php /**PATH E:\XaMpP\htdocs\tweety\resources\views/_mayKnowFriends.blade.php ENDPATH**/ ?>