<li class="msg-list-item d-flex justify-content-between">
    <!-- profile picture end -->
    <div class="profile-thumb">
        <figure class="profile-thumb-middle">
            <img src="<?php echo e(asset('user/images/profile/')); ?>/<?php echo e($notify->notifier_image); ?>" alt="profile picture">
        </figure>
    </div>
    <!-- profile picture end -->

    <!-- message content start -->
    <div class="msg-content notification-content">
        <a href=""><?php echo e($notify->notifier_name); ?></a>,
        <p><?php echo e($notify->data); ?></p>
    </div>
    <!-- message content end -->

    <!-- message time start -->
    <div class="msg-time">
        <p><?php echo e($notify->created_at->diffForHumans()); ?></p>
    </div>
    <!-- message time end -->
</li>
<?php /**PATH E:\XaMpP\htdocs\tweety\resources\views/notifications.blade.php ENDPATH**/ ?>